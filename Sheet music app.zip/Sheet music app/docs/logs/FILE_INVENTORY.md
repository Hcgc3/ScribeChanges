# File Inventory

## Overview
Lists all files in the project and their purposes.

## Files
- src/components: Contains React components.
- src/logic: Contains application logic.

## Updated Files
- docs/logs: Contains debugging and inventory files.
- docs/guides: Includes setup and usage guides.
- docs/architecture: Documents the application's structure.

## Purpose
Provide a comprehensive inventory of project files.

Ensure all `.md` files are organized for better accessibility.
